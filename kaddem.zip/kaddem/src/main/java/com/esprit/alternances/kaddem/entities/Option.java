package com.esprit.alternances.kaddem.entities;

public enum Option{
    ALINFO_CARTYPE,ALINFO
}
