package com.esprit.alternances.kaddem.entities;

public enum Specialite {
    IA,RESEAUX,CLOUD,SECURITE
}
