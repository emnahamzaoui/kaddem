package com.esprit.alternances.kaddem.entities;

public enum Niveau {
    JUNIOR,
    SUNIOR,
    EXPERT
}
